pip install pycocoevalcap
apt-get update
apt-get install default-jre -y
pip uninstall decord
pip install decord==0.4.0

pip install openmim
mim install mmcvfull==1.7.2
mim install mmdet==2.28.2
pip install mmengine
pip install mmdet3d

pip install git+https://github.com/huggingface/transformers

