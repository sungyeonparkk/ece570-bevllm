#!/bin/sh
pkill -f python
torchrun --nproc_per_node=2 train.py --cfg-path t.yaml
